import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Upload, X } from "lucide-react";
import { toast } from "sonner";

export function ImageUploader({
  value, onChange, folder = "general", max = 6,
}: { value: string[]; onChange: (urls: string[]) => void; folder?: string; max?: number }) {
  const [busy, setBusy] = useState(false);

  async function handleFiles(files: FileList | null) {
    if (!files || !files.length) return;
    if (value.length + files.length > max) return toast.error(`Max ${max} images`);
    setBusy(true);
    const uploaded: string[] = [];
    for (const file of Array.from(files)) {
      const ext = file.name.split(".").pop();
      const path = `${folder}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const { error } = await supabase.storage.from("part-images").upload(path, file);
      if (error) { toast.error(error.message); continue; }
      const { data } = supabase.storage.from("part-images").getPublicUrl(path);
      uploaded.push(data.publicUrl);
    }
    onChange([...value, ...uploaded]);
    setBusy(false);
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {value.map((url, i) => (
          <div key={i} className="group relative h-20 w-20 overflow-hidden rounded-md border">
            <img src={url} alt="" className="h-full w-full object-cover" />
            <button type="button" onClick={() => onChange(value.filter((_, j) => j !== i))}
              className="absolute right-1 top-1 rounded-full bg-destructive p-0.5 text-destructive-foreground opacity-0 group-hover:opacity-100">
              <X className="h-3 w-3" />
            </button>
          </div>
        ))}
        {value.length < max && (
          <label className="flex h-20 w-20 cursor-pointer items-center justify-center rounded-md border-2 border-dashed border-border hover:border-primary">
            <input type="file" accept="image/*" multiple className="hidden"
              disabled={busy} onChange={(e) => handleFiles(e.target.files)} />
            <Upload className="h-5 w-5 text-muted-foreground" />
          </label>
        )}
      </div>
      {busy && <p className="text-xs text-muted-foreground">Uploading…</p>}
    </div>
  );
}
