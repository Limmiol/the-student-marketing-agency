export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      part_events: {
        Row: {
          catalog_part_id: string | null
          cost: number
          created_at: string
          description: string | null
          event_type: Database["public"]["Enums"]["event_type"]
          id: string
          image_urls: string[]
          performed_by: string | null
          vehicle_id: string
          vehicle_part_id: string | null
        }
        Insert: {
          catalog_part_id?: string | null
          cost?: number
          created_at?: string
          description?: string | null
          event_type: Database["public"]["Enums"]["event_type"]
          id?: string
          image_urls?: string[]
          performed_by?: string | null
          vehicle_id: string
          vehicle_part_id?: string | null
        }
        Update: {
          catalog_part_id?: string | null
          cost?: number
          created_at?: string
          description?: string | null
          event_type?: Database["public"]["Enums"]["event_type"]
          id?: string
          image_urls?: string[]
          performed_by?: string | null
          vehicle_id?: string
          vehicle_part_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "part_events_catalog_part_id_fkey"
            columns: ["catalog_part_id"]
            isOneToOne: false
            referencedRelation: "parts_catalog"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "part_events_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "part_events_vehicle_part_id_fkey"
            columns: ["vehicle_part_id"]
            isOneToOne: false
            referencedRelation: "vehicle_parts"
            referencedColumns: ["id"]
          },
        ]
      }
      parts_catalog: {
        Row: {
          category: string
          created_at: string
          default_price: number | null
          description: string | null
          id: string
          name: string
          part_number: string | null
        }
        Insert: {
          category: string
          created_at?: string
          default_price?: number | null
          description?: string | null
          id?: string
          name: string
          part_number?: string | null
        }
        Update: {
          category?: string
          created_at?: string
          default_price?: number | null
          description?: string | null
          id?: string
          name?: string
          part_number?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string | null
          id: string
          phone: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          phone?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          phone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      purchase_requests: {
        Row: {
          admin_notes: string | null
          catalog_part_id: string | null
          created_at: string
          estimated_price: number
          id: string
          part_name_snapshot: string
          quantity: number
          reason: string | null
          requested_by: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: Database["public"]["Enums"]["request_status"]
          updated_at: string
          urgency: Database["public"]["Enums"]["request_urgency"]
          vehicle_id: string | null
        }
        Insert: {
          admin_notes?: string | null
          catalog_part_id?: string | null
          created_at?: string
          estimated_price?: number
          id?: string
          part_name_snapshot: string
          quantity?: number
          reason?: string | null
          requested_by?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["request_status"]
          updated_at?: string
          urgency?: Database["public"]["Enums"]["request_urgency"]
          vehicle_id?: string | null
        }
        Update: {
          admin_notes?: string | null
          catalog_part_id?: string | null
          created_at?: string
          estimated_price?: number
          id?: string
          part_name_snapshot?: string
          quantity?: number
          reason?: string | null
          requested_by?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["request_status"]
          updated_at?: string
          urgency?: Database["public"]["Enums"]["request_urgency"]
          vehicle_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "purchase_requests_catalog_part_id_fkey"
            columns: ["catalog_part_id"]
            isOneToOne: false
            referencedRelation: "parts_catalog"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "purchase_requests_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      safari_trips: {
        Row: {
          actual_return_date: string | null
          client_name: string | null
          created_at: string
          created_by: string | null
          destination: string
          driver_id: string | null
          driver_name: string | null
          end_mileage_km: number | null
          id: string
          notes: string | null
          planned_days: number
          start_date: string
          start_mileage_km: number | null
          status: Database["public"]["Enums"]["trip_status"]
          updated_at: string
          vehicle_id: string
        }
        Insert: {
          actual_return_date?: string | null
          client_name?: string | null
          created_at?: string
          created_by?: string | null
          destination: string
          driver_id?: string | null
          driver_name?: string | null
          end_mileage_km?: number | null
          id?: string
          notes?: string | null
          planned_days?: number
          start_date: string
          start_mileage_km?: number | null
          status?: Database["public"]["Enums"]["trip_status"]
          updated_at?: string
          vehicle_id: string
        }
        Update: {
          actual_return_date?: string | null
          client_name?: string | null
          created_at?: string
          created_by?: string | null
          destination?: string
          driver_id?: string | null
          driver_name?: string | null
          end_mileage_km?: number | null
          id?: string
          notes?: string | null
          planned_days?: number
          start_date?: string
          start_mileage_km?: number | null
          status?: Database["public"]["Enums"]["trip_status"]
          updated_at?: string
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "safari_trips_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vehicle_parts: {
        Row: {
          catalog_part_id: string
          created_at: string
          current_price: number | null
          id: string
          last_serviced_at: string | null
          notes: string | null
          status: Database["public"]["Enums"]["part_status"]
          updated_at: string
          updated_by: string | null
          vehicle_id: string
        }
        Insert: {
          catalog_part_id: string
          created_at?: string
          current_price?: number | null
          id?: string
          last_serviced_at?: string | null
          notes?: string | null
          status?: Database["public"]["Enums"]["part_status"]
          updated_at?: string
          updated_by?: string | null
          vehicle_id: string
        }
        Update: {
          catalog_part_id?: string
          created_at?: string
          current_price?: number | null
          id?: string
          last_serviced_at?: string | null
          notes?: string | null
          status?: Database["public"]["Enums"]["part_status"]
          updated_at?: string
          updated_by?: string | null
          vehicle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_parts_catalog_part_id_fkey"
            columns: ["catalog_part_id"]
            isOneToOne: false
            referencedRelation: "parts_catalog"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "vehicle_parts_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicles: {
        Row: {
          color: string | null
          created_at: string
          created_by: string | null
          id: string
          image_url: string | null
          mileage_km: number
          model: string
          name: string
          notes: string | null
          plate_number: string
          status: Database["public"]["Enums"]["vehicle_status"]
          updated_at: string
          vin: string | null
          year: number | null
        }
        Insert: {
          color?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          image_url?: string | null
          mileage_km?: number
          model?: string
          name: string
          notes?: string | null
          plate_number: string
          status?: Database["public"]["Enums"]["vehicle_status"]
          updated_at?: string
          vin?: string | null
          year?: number | null
        }
        Update: {
          color?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          image_url?: string | null
          mileage_km?: number
          model?: string
          name?: string
          notes?: string | null
          plate_number?: string
          status?: Database["public"]["Enums"]["vehicle_status"]
          updated_at?: string
          vin?: string | null
          year?: number | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      refresh_trip_statuses: { Args: never; Returns: undefined }
    }
    Enums: {
      app_role: "admin" | "manager" | "driver"
      event_type:
        | "installed"
        | "inspected"
        | "repaired"
        | "replaced"
        | "damaged"
      part_status:
        | "ok"
        | "needs_inspection"
        | "needs_repair"
        | "needs_replacement"
        | "replaced"
      request_status: "pending" | "approved" | "rejected" | "purchased"
      request_urgency: "low" | "medium" | "high" | "critical"
      trip_status:
        | "planned"
        | "in_progress"
        | "completed"
        | "overdue"
        | "cancelled"
      vehicle_status: "available" | "on_safari" | "in_repair" | "out_of_service"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "manager", "driver"],
      event_type: ["installed", "inspected", "repaired", "replaced", "damaged"],
      part_status: [
        "ok",
        "needs_inspection",
        "needs_repair",
        "needs_replacement",
        "replaced",
      ],
      request_status: ["pending", "approved", "rejected", "purchased"],
      request_urgency: ["low", "medium", "high", "critical"],
      trip_status: [
        "planned",
        "in_progress",
        "completed",
        "overdue",
        "cancelled",
      ],
      vehicle_status: ["available", "on_safari", "in_repair", "out_of_service"],
    },
  },
} as const
