import { createFileRoute, Link, Navigate, Outlet, useLocation } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import { LayoutDashboard, Truck, Wrench, ShoppingCart, MapPinned, BarChart3, BookOpen, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated")({ component: AuthLayout });

const nav = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/vehicles", label: "Vehicles", icon: Truck },
  { to: "/catalog", label: "Parts Catalog", icon: BookOpen },
  { to: "/repairs", label: "Repairs & Photos", icon: Wrench },
  { to: "/purchases", label: "Purchase Requests", icon: ShoppingCart },
  { to: "/safaris", label: "Safari Trips", icon: MapPinned },
  { to: "/reports", label: "Reports", icon: BarChart3 },
] as const;

function AuthLayout() {
  const { session, loading, role, user, signOut } = useAuth();
  const location = useLocation();

  if (loading) return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Loading…</div>;
  if (!session) return <Navigate to="/auth" />;

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="hidden w-64 shrink-0 flex-col bg-sidebar text-sidebar-foreground md:flex">
        <div className="flex items-center gap-2 px-6 py-5 border-b border-sidebar-border">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-accent text-accent-foreground">
            <Truck className="h-5 w-5" />
          </div>
          <div>
            <div className="font-display font-bold">Safari Fleet</div>
            <div className="text-[10px] uppercase tracking-wider opacity-70">{role}</div>
          </div>
        </div>
        <nav className="flex-1 space-y-1 p-3">
          {nav.map((n) => {
            const active = location.pathname.startsWith(n.to);
            return (
              <Link key={n.to} to={n.to}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm transition",
                  active ? "bg-sidebar-accent text-sidebar-accent-foreground" : "hover:bg-sidebar-accent/60"
                )}>
                <n.icon className="h-4 w-4" />{n.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-sidebar-border p-3">
          <div className="px-2 pb-2 text-xs opacity-70 truncate">{user?.email}</div>
          <Button variant="secondary" size="sm" className="w-full" onClick={signOut}>
            <LogOut className="mr-2 h-4 w-4" />Sign out
          </Button>
        </div>
      </aside>
      <main className="flex-1 overflow-x-hidden">
        {/* mobile top bar */}
        <div className="flex items-center justify-between border-b bg-sidebar px-4 py-3 text-sidebar-foreground md:hidden">
          <div className="flex items-center gap-2"><Truck className="h-5 w-5" /><span className="font-semibold">Safari Fleet</span></div>
          <Button variant="secondary" size="sm" onClick={signOut}><LogOut className="h-4 w-4" /></Button>
        </div>
        <div className="md:hidden overflow-x-auto border-b bg-card">
          <div className="flex gap-1 p-2">
            {nav.map((n) => (
              <Link key={n.to} to={n.to} className="whitespace-nowrap rounded-md px-3 py-1.5 text-xs hover:bg-secondary">{n.label}</Link>
            ))}
          </div>
        </div>
        <div className="p-4 md:p-8"><Outlet /></div>
      </main>
    </div>
  );
}
