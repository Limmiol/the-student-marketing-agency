import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/catalog")({ component: CatalogPage });

function CatalogPage() {
  const { role } = useAuth();
  const canEdit = role === "admin" || role === "manager";
  const [items, setItems] = useState<any[]>([]);
  const [search, setSearch] = useState("");
  const [cat, setCat] = useState("all");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", category: "", part_number: "", description: "", default_price: "" });

  async function load() {
    const { data } = await supabase.from("parts_catalog").select("*").order("category").order("name");
    setItems(data ?? []);
  }
  useEffect(() => { load(); }, []);

  async function updatePrice(id: string, value: string) {
    const { error } = await supabase.from("parts_catalog").update({ default_price: value ? Number(value) : null }).eq("id", id);
    if (error) toast.error(error.message); else toast.success("Price updated");
  }

  async function add() {
    if (!form.name || !form.category) return toast.error("Name & category required");
    const { error } = await supabase.from("parts_catalog").insert({
      name: form.name, category: form.category, part_number: form.part_number || null,
      description: form.description || null, default_price: form.default_price ? Number(form.default_price) : null,
    });
    if (error) return toast.error(error.message);
    toast.success("Part added");
    setOpen(false); setForm({ name: "", category: "", part_number: "", description: "", default_price: "" });
    load();
  }

  const categories = Array.from(new Set(items.map((i) => i.category)));
  const filtered = items.filter((i) =>
    (cat === "all" || i.category === cat) &&
    (!search || i.name.toLowerCase().includes(search.toLowerCase()) || i.part_number?.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div>
      <PageHeader title="Parts Catalog" description={`${items.length} parts across ${categories.length} systems`}
        action={canEdit && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />Add part</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New catalog part</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Category</Label><Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="Engine, Brakes…" /></div>
                  <div><Label>Part number</Label><Input value={form.part_number} onChange={(e) => setForm({ ...form, part_number: e.target.value })} /></div>
                </div>
                <div><Label>Default price (USD)</Label><Input type="number" value={form.default_price} onChange={(e) => setForm({ ...form, default_price: e.target.value })} /></div>
                <div><Label>Description</Label><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
                <Button onClick={add} className="w-full">Save</Button>
              </div>
            </DialogContent>
          </Dialog>
        )} />

      <div className="mb-3 flex flex-wrap gap-2">
        <Input placeholder="Search…" value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-xs" />
        <Select value={cat} onValueChange={setCat}>
          <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <Card><CardContent className="p-0">
        <div className="max-h-[70vh] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-card text-left text-xs uppercase text-muted-foreground">
              <tr><th className="p-3">Part</th><th className="p-3">Category</th><th className="p-3">Part #</th><th className="p-3 w-40">Default price (USD)</th></tr>
            </thead>
            <tbody>
              {filtered.map((i) => (
                <tr key={i.id} className="border-t">
                  <td className="p-3 font-medium">{i.name}{i.description && <div className="text-xs text-muted-foreground">{i.description}</div>}</td>
                  <td className="p-3 text-muted-foreground">{i.category}</td>
                  <td className="p-3 text-muted-foreground">{i.part_number ?? "—"}</td>
                  <td className="p-3">
                    {canEdit ? (
                      <Input type="number" defaultValue={i.default_price ?? ""} className="h-8"
                        onBlur={(e) => e.target.value !== String(i.default_price ?? "") && updatePrice(i.id, e.target.value)} />
                    ) : (i.default_price?.toLocaleString() ?? "—")}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent></Card>
    </div>
  );
}
