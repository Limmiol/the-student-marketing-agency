import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Truck, Wrench, ShoppingCart, MapPinned, AlertTriangle, DollarSign } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { differenceInCalendarDays, format } from "date-fns";

export const Route = createFileRoute("/_authenticated/dashboard")({ component: Dashboard });

type Stats = {
  vehicles: number; onSafari: number; inRepair: number;
  pendingRequests: number; totalSpentMonth: number; activeTrips: any[]; recentRequests: any[];
};

function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);

  async function load() {
    await supabase.rpc("refresh_trip_statuses");
    const [v, t, p, e, tr] = await Promise.all([
      supabase.from("vehicles").select("status"),
      supabase.from("safari_trips").select("*, vehicles(name, plate_number)").in("status", ["in_progress", "overdue"]).order("start_date"),
      supabase.from("purchase_requests").select("*, vehicles(name)").eq("status", "pending").order("created_at", { ascending: false }).limit(5),
      supabase.from("part_events").select("cost, created_at").gte("created_at", new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString()),
      supabase.from("purchase_requests").select("id").eq("status", "pending"),
    ]);
    const vs = v.data ?? [];
    setStats({
      vehicles: vs.length,
      onSafari: vs.filter((x) => x.status === "on_safari").length,
      inRepair: vs.filter((x) => x.status === "in_repair").length,
      pendingRequests: tr.data?.length ?? 0,
      totalSpentMonth: (e.data ?? []).reduce((s, r) => s + Number(r.cost || 0), 0),
      activeTrips: t.data ?? [],
      recentRequests: p.data ?? [],
    });
  }

  useEffect(() => {
    load();
    const ch = supabase.channel("dash")
      .on("postgres_changes", { event: "*", schema: "public", table: "safari_trips" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "purchase_requests" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "vehicles" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "part_events" }, load)
      .subscribe();
    const t = setInterval(load, 60_000);
    return () => { supabase.removeChannel(ch); clearInterval(t); };
  }, []);

  if (!stats) return <p className="text-muted-foreground">Loading…</p>;

  const cards = [
    { label: "Total Vehicles", value: stats.vehicles, icon: Truck, color: "text-primary" },
    { label: "On Safari", value: stats.onSafari, icon: MapPinned, color: "text-accent" },
    { label: "In Repair", value: stats.inRepair, icon: Wrench, color: "text-warning" },
    { label: "Pending Requests", value: stats.pendingRequests, icon: ShoppingCart, color: "text-destructive" },
  ];

  return (
    <div>
      <PageHeader title="Dashboard" description="Real-time fleet overview" />

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {cards.map((c) => (
          <Card key={c.label}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs uppercase tracking-wider text-muted-foreground">{c.label}</p>
                  <p className="mt-1 text-3xl font-bold">{c.value}</p>
                </div>
                <c.icon className={`h-8 w-8 ${c.color}`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2"><MapPinned className="h-4 w-4" /> Active Safaris</CardTitle>
            <Link to="/safaris" className="text-xs text-primary hover:underline">View all</Link>
          </CardHeader>
          <CardContent className="space-y-3">
            {stats.activeTrips.length === 0 && <p className="text-sm text-muted-foreground">No safari in progress.</p>}
            {stats.activeTrips.map((t: any) => {
              const day = differenceInCalendarDays(new Date(), new Date(t.start_date)) + 1;
              const isOverdue = day > t.planned_days;
              const isReturning = day === t.planned_days;
              return (
                <div key={t.id} className="rounded-lg border bg-card p-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="font-semibold">{t.vehicles?.name} <span className="text-xs text-muted-foreground">· {t.vehicles?.plate_number}</span></div>
                      <div className="text-xs text-muted-foreground">{t.destination} · Driver: {t.driver_name || "—"}</div>
                    </div>
                    <Badge variant={isOverdue ? "destructive" : isReturning ? "default" : "secondary"}>
                      {isOverdue ? `Overdue +${day - t.planned_days}d`
                        : isReturning ? "Returning today"
                        : `Day ${day} of ${t.planned_days}`}
                    </Badge>
                  </div>
                  <div className="mt-2 h-1.5 w-full overflow-hidden rounded bg-secondary">
                    <div className={`h-full ${isOverdue ? "bg-destructive" : "bg-primary"}`}
                      style={{ width: `${Math.min(100, (day / t.planned_days) * 100)}%` }} />
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2"><ShoppingCart className="h-4 w-4" /> Recent Purchase Requests</CardTitle>
            <Link to="/purchases" className="text-xs text-primary hover:underline">View all</Link>
          </CardHeader>
          <CardContent className="space-y-2">
            {stats.recentRequests.length === 0 && <p className="text-sm text-muted-foreground">No pending requests.</p>}
            {stats.recentRequests.map((r: any) => (
              <div key={r.id} className="flex items-center justify-between rounded border p-2 text-sm">
                <div>
                  <div className="font-medium">{r.part_name_snapshot} <span className="text-xs text-muted-foreground">× {r.quantity}</span></div>
                  <div className="text-xs text-muted-foreground">{r.vehicles?.name ?? "Unassigned"} · {format(new Date(r.created_at), "MMM d, HH:mm")}</div>
                </div>
                <Badge variant={r.urgency === "critical" ? "destructive" : r.urgency === "high" ? "default" : "secondary"}>{r.urgency}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card className="mt-4">
        <CardContent className="flex items-center gap-4 p-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-accent/20 text-accent"><DollarSign className="h-6 w-6" /></div>
          <div>
            <p className="text-xs uppercase tracking-wider text-muted-foreground">Spent on parts this month</p>
            <p className="text-2xl font-bold">{stats.totalSpentMonth.toLocaleString()} <span className="text-sm font-normal text-muted-foreground">USD</span></p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
