import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Check, X } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";
import { format } from "date-fns";

export const Route = createFileRoute("/_authenticated/purchases")({ component: PurchasesPage });

const URGENCY_COLOR: any = { critical: "destructive", high: "default", medium: "secondary", low: "secondary" };
const STATUS_COLOR: any = { pending: "default", approved: "secondary", rejected: "destructive", purchased: "secondary" };

function PurchasesPage() {
  const { role, user } = useAuth();
  const isAdmin = role === "admin";
  const canCreate = role === "admin" || role === "manager";
  const [items, setItems] = useState<any[]>([]);
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [catalog, setCatalog] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ vehicle_id: "", catalog_part_id: "", part_name: "", quantity: "1", estimated_price: "", urgency: "medium", reason: "" });

  async function load() {
    const [r, v, c] = await Promise.all([
      supabase.from("purchase_requests").select("*, vehicles(name, plate_number)").order("created_at", { ascending: false }),
      supabase.from("vehicles").select("id, name, plate_number").order("name"),
      supabase.from("parts_catalog").select("id, name, category, default_price").order("name"),
    ]);
    setItems(r.data ?? []); setVehicles(v.data ?? []); setCatalog(c.data ?? []);
  }

  useEffect(() => {
    load();
    const ch = supabase.channel("preqs").on("postgres_changes", { event: "*", schema: "public", table: "purchase_requests" }, load).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  function selectPart(id: string) {
    const p = catalog.find((x) => x.id === id);
    setForm({ ...form, catalog_part_id: id, part_name: p?.name ?? "", estimated_price: p?.default_price?.toString() ?? "" });
  }

  async function create() {
    if (!form.part_name) return toast.error("Part name required");
    const { error } = await supabase.from("purchase_requests").insert({
      vehicle_id: form.vehicle_id || null,
      catalog_part_id: form.catalog_part_id || null,
      part_name_snapshot: form.part_name,
      quantity: Number(form.quantity) || 1,
      estimated_price: form.estimated_price ? Number(form.estimated_price) : 0,
      urgency: form.urgency as any,
      reason: form.reason || null,
      requested_by: user?.id,
    });
    if (error) return toast.error(error.message);
    toast.success("Request submitted");
    setOpen(false);
    setForm({ vehicle_id: "", catalog_part_id: "", part_name: "", quantity: "1", estimated_price: "", urgency: "medium", reason: "" });
  }

  async function review(id: string, status: "approved" | "rejected" | "purchased") {
    const { error } = await supabase.from("purchase_requests")
      .update({ status, reviewed_by: user?.id, reviewed_at: new Date().toISOString() })
      .eq("id", id);
    if (error) return toast.error(error.message);
    toast.success(`Marked ${status}`);
  }

  const pending = items.filter((i) => i.status === "pending");
  const done = items.filter((i) => i.status !== "pending");

  return (
    <div>
      <PageHeader title="Purchase Requests" description="Managers request parts → Admin approves in real time"
        action={canCreate && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />New request</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Request a part</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Catalog part (optional)</Label>
                  <Select value={form.catalog_part_id} onValueChange={selectPart}>
                    <SelectTrigger><SelectValue placeholder="Pick from catalog or type below" /></SelectTrigger>
                    <SelectContent className="max-h-72">
                      {catalog.map((c) => <SelectItem key={c.id} value={c.id}>{c.category} — {c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div><Label>Part name</Label><Input value={form.part_name} onChange={(e) => setForm({ ...form, part_name: e.target.value })} /></div>
                <div className="grid grid-cols-3 gap-2">
                  <div><Label>Qty</Label><Input type="number" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /></div>
                  <div><Label>Est. price</Label><Input type="number" value={form.estimated_price} onChange={(e) => setForm({ ...form, estimated_price: e.target.value })} /></div>
                  <div><Label>Urgency</Label>
                    <Select value={form.urgency} onValueChange={(v) => setForm({ ...form, urgency: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem><SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem><SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div><Label>For vehicle</Label>
                  <Select value={form.vehicle_id} onValueChange={(v) => setForm({ ...form, vehicle_id: v })}>
                    <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                    <SelectContent>{vehicles.map((v) => <SelectItem key={v.id} value={v.id}>{v.name} — {v.plate_number}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Reason</Label><Textarea value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} rows={2} /></div>
                <Button onClick={create} className="w-full">Submit request</Button>
              </div>
            </DialogContent>
          </Dialog>
        )} />

      <Tabs defaultValue="pending">
        <TabsList><TabsTrigger value="pending">Pending ({pending.length})</TabsTrigger><TabsTrigger value="done">History ({done.length})</TabsTrigger></TabsList>
        <TabsContent value="pending" className="space-y-2">
          {pending.length === 0 && <Card><CardContent className="py-6 text-center text-muted-foreground">No pending requests.</CardContent></Card>}
          {pending.map((r) => (
            <Card key={r.id}><CardContent className="p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">{r.part_name_snapshot}</span>
                    <Badge variant={URGENCY_COLOR[r.urgency]}>{r.urgency}</Badge>
                  </div>
                  <div className="text-xs text-muted-foreground">Qty: {r.quantity} · Est. {Number(r.estimated_price).toLocaleString()} USD · {r.vehicles?.name ?? "Unassigned"}</div>
                  <div className="text-xs text-muted-foreground">{format(new Date(r.created_at), "MMM d, yyyy HH:mm")}</div>
                  {r.reason && <p className="mt-1 text-sm">{r.reason}</p>}
                </div>
                {isAdmin && (
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => review(r.id, "approved")}><Check className="mr-1 h-3 w-3" />Approve</Button>
                    <Button size="sm" variant="destructive" onClick={() => review(r.id, "rejected")}><X className="mr-1 h-3 w-3" />Reject</Button>
                  </div>
                )}
              </div>
            </CardContent></Card>
          ))}
        </TabsContent>
        <TabsContent value="done" className="space-y-2">
          {done.map((r) => (
            <Card key={r.id}><CardContent className="flex items-center justify-between p-3 text-sm">
              <div><div className="font-medium">{r.part_name_snapshot} <span className="text-xs text-muted-foreground">× {r.quantity}</span></div>
                <div className="text-xs text-muted-foreground">{r.vehicles?.name ?? "—"} · {format(new Date(r.created_at), "MMM d")}</div></div>
              <div className="flex items-center gap-2">
                <Badge variant={STATUS_COLOR[r.status]}>{r.status}</Badge>
                {isAdmin && r.status === "approved" && <Button size="sm" variant="outline" onClick={() => review(r.id, "purchased")}>Mark purchased</Button>}
              </div>
            </CardContent></Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
