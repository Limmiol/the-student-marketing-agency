import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/repairs")({ component: RepairsPage });

function RepairsPage() {
  return (
    <div>
      <PageHeader title="Repairs & Photos" description="Log a repair from a vehicle's parts list" />
      <Card><CardContent className="py-10 text-center">
        <p className="text-muted-foreground">Open a vehicle to log a repair, change a part status, attach photos, and set new prices.</p>
        <Link to="/vehicles" className="mt-3 inline-block text-primary hover:underline">→ Go to Vehicles</Link>
      </CardContent></Card>
    </div>
  );
}
