import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format, startOfDay, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isSameMonth } from "date-fns";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/reports")({ component: ReportsPage });

function ReportsPage() {
  const [events, setEvents] = useState<any[]>([]);
  const [trips, setTrips] = useState<any[]>([]);
  const [vehicles, setVehicles] = useState<any[]>([]);

  useEffect(() => {
    Promise.all([
      supabase.from("part_events").select("*, vehicles(name, plate_number), parts_catalog(name)").order("created_at", { ascending: false }),
      supabase.from("safari_trips").select("*, vehicles(name)"),
      supabase.from("vehicles").select("*"),
    ]).then(([e, t, v]) => { setEvents(e.data ?? []); setTrips(t.data ?? []); setVehicles(v.data ?? []); });
  }, []);

  const today = startOfDay(new Date());
  const monthStart = startOfMonth(new Date());
  const monthEnd = endOfMonth(new Date());

  const todayEvents = events.filter((e) => isSameDay(new Date(e.created_at), today));
  const monthEvents = events.filter((e) => isSameMonth(new Date(e.created_at), today));
  const todayTrips = trips.filter((t) => isSameDay(new Date(t.start_date), today));
  const monthTrips = trips.filter((t) => isSameMonth(new Date(t.start_date), today));

  const todaySpent = todayEvents.reduce((s, e) => s + Number(e.cost || 0), 0);
  const monthSpent = monthEvents.reduce((s, e) => s + Number(e.cost || 0), 0);

  const perVehicle = useMemo(() => {
    const map = new Map<string, { name: string; plate: string; spent: number; events: number; trips: number }>();
    vehicles.forEach((v) => map.set(v.id, { name: v.name, plate: v.plate_number, spent: 0, events: 0, trips: 0 }));
    events.forEach((e) => { const m = map.get(e.vehicle_id); if (m) { m.spent += Number(e.cost || 0); m.events += 1; } });
    trips.forEach((t) => { const m = map.get(t.vehicle_id); if (m) m.trips += 1; });
    return Array.from(map.values()).sort((a, b) => b.spent - a.spent);
  }, [vehicles, events, trips]);

  const dailyChart = useMemo(() => {
    return eachDayOfInterval({ start: monthStart, end: monthEnd }).map((d) => ({
      date: format(d, "d"),
      spent: events.filter((e) => isSameDay(new Date(e.created_at), d)).reduce((s, e) => s + Number(e.cost || 0), 0),
    }));
  }, [events, monthStart, monthEnd]);

  const maxDaily = Math.max(1, ...dailyChart.map((d) => d.spent));

  function downloadCSV(rows: any[], filename: string) {
    if (!rows.length) return;
    const headers = Object.keys(rows[0]);
    const csv = [headers.join(","), ...rows.map((r) => headers.map((h) => `"${String(r[h] ?? "").replace(/"/g, '""')}"`).join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <PageHeader title="Reports" description="Daily & monthly fleet activity" />

      <Tabs defaultValue="daily">
        <TabsList><TabsTrigger value="daily">Daily ({format(today, "MMM d")})</TabsTrigger><TabsTrigger value="monthly">Monthly ({format(today, "MMMM yyyy")})</TabsTrigger><TabsTrigger value="vehicles">By Vehicle</TabsTrigger></TabsList>

        <TabsContent value="daily" className="space-y-4">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <StatCard label="Repairs today" value={todayEvents.length} />
            <StatCard label="Spent today" value={`${todaySpent.toLocaleString()} USD`} />
            <StatCard label="Safaris starting" value={todayTrips.length} />
            <StatCard label="Active fleet" value={vehicles.filter((v) => v.status === "on_safari").length} />
          </div>
          <Card><CardHeader className="flex flex-row items-center justify-between"><CardTitle>Today's repair events</CardTitle>
            <Button size="sm" variant="outline" onClick={() => downloadCSV(todayEvents.map((e) => ({ date: e.created_at, vehicle: e.vehicles?.name, part: e.parts_catalog?.name, type: e.event_type, cost: e.cost, notes: e.description })), `daily-${format(today, "yyyy-MM-dd")}.csv`)}><Download className="mr-1 h-3 w-3" />CSV</Button>
          </CardHeader><CardContent>
            {todayEvents.length === 0 ? <p className="text-sm text-muted-foreground">No repairs logged today.</p> :
              <EventTable rows={todayEvents} />}
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="monthly" className="space-y-4">
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <StatCard label="Repairs this month" value={monthEvents.length} />
            <StatCard label="Spent this month" value={`${monthSpent.toLocaleString()} USD`} />
            <StatCard label="Safaris this month" value={monthTrips.length} />
            <StatCard label="Avg / repair" value={`${monthEvents.length ? Math.round(monthSpent / monthEvents.length).toLocaleString() : 0} USD`} />
          </div>

          <Card><CardHeader><CardTitle>Daily spend ({format(today, "MMMM")})</CardTitle></CardHeader><CardContent>
            <div className="flex h-40 items-end gap-1">
              {dailyChart.map((d) => (
                <div key={d.date} className="flex flex-1 flex-col items-center gap-1" title={`Day ${d.date}: ${d.spent.toLocaleString()} USD`}>
                  <div className="w-full rounded-t bg-primary transition" style={{ height: `${(d.spent / maxDaily) * 100}%`, minHeight: d.spent ? "2px" : "0" }} />
                  <div className="text-[10px] text-muted-foreground">{d.date}</div>
                </div>
              ))}
            </div>
          </CardContent></Card>

          <Card><CardHeader className="flex flex-row items-center justify-between"><CardTitle>Monthly events</CardTitle>
            <Button size="sm" variant="outline" onClick={() => downloadCSV(monthEvents.map((e) => ({ date: e.created_at, vehicle: e.vehicles?.name, part: e.parts_catalog?.name, type: e.event_type, cost: e.cost, notes: e.description })), `monthly-${format(today, "yyyy-MM")}.csv`)}><Download className="mr-1 h-3 w-3" />CSV</Button>
          </CardHeader><CardContent>
            <EventTable rows={monthEvents.slice(0, 100)} />
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="vehicles" className="space-y-4">
          <Card><CardHeader><CardTitle>Spending per vehicle (all time)</CardTitle></CardHeader><CardContent className="p-0">
            <table className="w-full text-sm">
              <thead className="bg-secondary text-left text-xs uppercase text-muted-foreground"><tr><th className="p-3">Vehicle</th><th className="p-3">Trips</th><th className="p-3">Repairs</th><th className="p-3 text-right">Total spent (USD)</th></tr></thead>
              <tbody>
                {perVehicle.map((v) => (
                  <tr key={v.plate} className="border-t">
                    <td className="p-3 font-medium">{v.name} <span className="text-xs text-muted-foreground">· {v.plate}</span></td>
                    <td className="p-3">{v.trips}</td><td className="p-3">{v.events}</td>
                    <td className="p-3 text-right font-bold">{v.spent.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent></Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: any }) {
  return <Card><CardContent className="p-4"><div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div><div className="mt-1 text-2xl font-bold">{value}</div></CardContent></Card>;
}

function EventTable({ rows }: { rows: any[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-left text-xs uppercase text-muted-foreground"><tr><th className="p-2">When</th><th className="p-2">Vehicle</th><th className="p-2">Part</th><th className="p-2">Event</th><th className="p-2 text-right">Cost</th></tr></thead>
        <tbody>
          {rows.map((e) => (
            <tr key={e.id} className="border-t">
              <td className="p-2 text-muted-foreground">{format(new Date(e.created_at), "MMM d HH:mm")}</td>
              <td className="p-2">{e.vehicles?.name ?? "—"}</td>
              <td className="p-2">{e.parts_catalog?.name ?? "—"}</td>
              <td className="p-2">{e.event_type}</td>
              <td className="p-2 text-right font-medium">{Number(e.cost).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
