import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, MapPinned } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";
import { differenceInCalendarDays, format } from "date-fns";

export const Route = createFileRoute("/_authenticated/safaris")({ component: SafarisPage });

function SafarisPage() {
  const { role, user } = useAuth();
  const canEdit = role === "admin" || role === "manager";
  const [trips, setTrips] = useState<any[]>([]);
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ vehicle_id: "", destination: "", client_name: "", driver_name: "", start_date: format(new Date(), "yyyy-MM-dd"), planned_days: "3", start_mileage_km: "", notes: "" });

  async function load() {
    await supabase.rpc("refresh_trip_statuses");
    const [t, v] = await Promise.all([
      supabase.from("safari_trips").select("*, vehicles(name, plate_number)").order("start_date", { ascending: false }),
      supabase.from("vehicles").select("id, name, plate_number").order("name"),
    ]);
    setTrips(t.data ?? []); setVehicles(v.data ?? []);
  }
  useEffect(() => {
    load();
    const ch = supabase.channel("trips").on("postgres_changes", { event: "*", schema: "public", table: "safari_trips" }, load).subscribe();
    const t = setInterval(load, 60_000);
    return () => { supabase.removeChannel(ch); clearInterval(t); };
  }, []);

  async function create() {
    if (!form.vehicle_id || !form.destination) return toast.error("Vehicle & destination required");
    const { error } = await supabase.from("safari_trips").insert({
      vehicle_id: form.vehicle_id, destination: form.destination, client_name: form.client_name || null,
      driver_name: form.driver_name || null, start_date: form.start_date,
      planned_days: Number(form.planned_days) || 1,
      start_mileage_km: form.start_mileage_km ? Number(form.start_mileage_km) : null,
      notes: form.notes || null, created_by: user?.id,
      status: new Date(form.start_date) <= new Date() ? "in_progress" : "planned",
    });
    if (error) return toast.error(error.message);
    await supabase.from("vehicles").update({ status: "on_safari" }).eq("id", form.vehicle_id);
    toast.success("Safari logged");
    setOpen(false);
    setForm({ vehicle_id: "", destination: "", client_name: "", driver_name: "", start_date: format(new Date(), "yyyy-MM-dd"), planned_days: "3", start_mileage_km: "", notes: "" });
  }

  async function complete(t: any) {
    const km = prompt("Return mileage (km)?", String(t.start_mileage_km ?? ""));
    const { error } = await supabase.from("safari_trips").update({
      status: "completed", actual_return_date: format(new Date(), "yyyy-MM-dd"),
      end_mileage_km: km ? Number(km) : null,
    }).eq("id", t.id);
    if (error) return toast.error(error.message);
    if (t.vehicle_id) await supabase.from("vehicles").update({ status: "available", mileage_km: km ? Number(km) : undefined }).eq("id", t.vehicle_id);
    toast.success("Trip completed");
  }

  const active = trips.filter((t) => ["in_progress", "overdue", "planned"].includes(t.status));
  const past = trips.filter((t) => ["completed", "cancelled"].includes(t.status));

  return (
    <div>
      <PageHeader title="Safari Trips" description="Real-time day tracking for every safari"
        action={canEdit && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />New safari</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>Log a safari</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Vehicle</Label>
                  <Select value={form.vehicle_id} onValueChange={(v) => setForm({ ...form, vehicle_id: v })}>
                    <SelectTrigger><SelectValue placeholder="Pick a vehicle" /></SelectTrigger>
                    <SelectContent>{vehicles.map((v) => <SelectItem key={v.id} value={v.id}>{v.name} — {v.plate_number}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div><Label>Destination</Label><Input value={form.destination} onChange={(e) => setForm({ ...form, destination: e.target.value })} placeholder="Serengeti, Mara…" /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Client</Label><Input value={form.client_name} onChange={(e) => setForm({ ...form, client_name: e.target.value })} /></div>
                  <div><Label>Driver</Label><Input value={form.driver_name} onChange={(e) => setForm({ ...form, driver_name: e.target.value })} /></div>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div><Label>Start date</Label><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} /></div>
                  <div><Label>Days</Label><Input type="number" value={form.planned_days} onChange={(e) => setForm({ ...form, planned_days: e.target.value })} /></div>
                  <div><Label>Start km</Label><Input type="number" value={form.start_mileage_km} onChange={(e) => setForm({ ...form, start_mileage_km: e.target.value })} /></div>
                </div>
                <div><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} /></div>
                <Button onClick={create} className="w-full">Save</Button>
              </div>
            </DialogContent>
          </Dialog>
        )} />

      <h2 className="mb-2 text-lg font-semibold flex items-center gap-2"><MapPinned className="h-5 w-5" />Active</h2>
      <div className="mb-6 space-y-2">
        {active.length === 0 && <Card><CardContent className="py-6 text-center text-muted-foreground">No active safaris.</CardContent></Card>}
        {active.map((t) => {
          const day = Math.max(1, differenceInCalendarDays(new Date(), new Date(t.start_date)) + 1);
          const overdue = day > t.planned_days;
          const returning = day === t.planned_days;
          const upcoming = new Date(t.start_date) > new Date();
          return (
            <Card key={t.id}><CardContent className="p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-semibold">{t.vehicles?.name} <span className="text-xs text-muted-foreground">· {t.vehicles?.plate_number}</span></div>
                  <div className="text-sm">{t.destination}</div>
                  <div className="text-xs text-muted-foreground">Client: {t.client_name ?? "—"} · Driver: {t.driver_name ?? "—"} · Start {format(new Date(t.start_date), "MMM d")}</div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={overdue ? "destructive" : returning ? "default" : upcoming ? "secondary" : "default"}>
                    {upcoming ? `Starts ${format(new Date(t.start_date), "MMM d")}`
                      : overdue ? `Overdue by ${day - t.planned_days} day(s)`
                      : returning ? "Returning today"
                      : `Day ${day} of ${t.planned_days}`}
                  </Badge>
                  {canEdit && !upcoming && <Button size="sm" variant="outline" onClick={() => complete(t)}>Complete</Button>}
                </div>
              </div>
              {!upcoming && (
                <div className="mt-3 h-2 w-full overflow-hidden rounded bg-secondary">
                  <div className={`h-full ${overdue ? "bg-destructive" : "bg-primary"}`} style={{ width: `${Math.min(100, (day / t.planned_days) * 100)}%` }} />
                </div>
              )}
            </CardContent></Card>
          );
        })}
      </div>

      <h2 className="mb-2 text-lg font-semibold">Past trips</h2>
      <div className="space-y-2">
        {past.slice(0, 30).map((t) => (
          <Card key={t.id}><CardContent className="flex items-center justify-between p-3 text-sm">
            <div>
              <div className="font-medium">{t.vehicles?.name} → {t.destination}</div>
              <div className="text-xs text-muted-foreground">{format(new Date(t.start_date), "MMM d, yyyy")} · {t.planned_days}d · {t.driver_name ?? "—"}</div>
            </div>
            <Badge variant="secondary">{t.status}</Badge>
          </CardContent></Card>
        ))}
      </div>
    </div>
  );
}
