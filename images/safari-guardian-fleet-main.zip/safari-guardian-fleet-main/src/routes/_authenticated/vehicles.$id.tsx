import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Wrench, DollarSign, History } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";
import { ImageUploader } from "@/components/ImageUploader";
import { format } from "date-fns";

export const Route = createFileRoute("/_authenticated/vehicles/$id")({ component: VehicleDetail });

const PART_STATUS_COLOR: Record<string, "default" | "secondary" | "destructive"> = {
  ok: "default", needs_inspection: "secondary", needs_repair: "destructive", needs_replacement: "destructive", replaced: "default",
};

function VehicleDetail() {
  const { id } = Route.useParams();
  const { role } = useAuth();
  const canEdit = role === "admin" || role === "manager";
  const [vehicle, setVehicle] = useState<any>(null);
  const [catalog, setCatalog] = useState<any[]>([]);
  const [parts, setParts] = useState<any[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [trips, setTrips] = useState<any[]>([]);
  const [filterCat, setFilterCat] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [selectedPart, setSelectedPart] = useState<any>(null);

  async function load() {
    const [v, c, p, e, t] = await Promise.all([
      supabase.from("vehicles").select("*").eq("id", id).single(),
      supabase.from("parts_catalog").select("*").order("category").order("name"),
      supabase.from("vehicle_parts").select("*, parts_catalog(*)").eq("vehicle_id", id),
      supabase.from("part_events").select("*, parts_catalog(name)").eq("vehicle_id", id).order("created_at", { ascending: false }).limit(50),
      supabase.from("safari_trips").select("*").eq("vehicle_id", id).order("start_date", { ascending: false }).limit(20),
    ]);
    setVehicle(v.data); setCatalog(c.data ?? []); setParts(p.data ?? []); setEvents(e.data ?? []); setTrips(t.data ?? []);
  }

  useEffect(() => {
    load();
    const ch = supabase.channel(`v-${id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "vehicle_parts", filter: `vehicle_id=eq.${id}` }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "part_events", filter: `vehicle_id=eq.${id}` }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [id]);

  if (!vehicle) return <p className="text-muted-foreground">Loading…</p>;

  const categories = Array.from(new Set(catalog.map((c) => c.category)));
  const partMap = new Map(parts.map((p) => [p.catalog_part_id, p]));
  const totalSpent = events.reduce((s, e) => s + Number(e.cost || 0), 0);

  const filteredCatalog = catalog.filter((c) =>
    (filterCat === "all" || c.category === filterCat) &&
    (!search || c.name.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div>
      <Link to="/vehicles" className="mb-4 inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="mr-1 h-4 w-4" />Back to vehicles
      </Link>

      <div className="mb-6 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold">{vehicle.name}</h1>
          <p className="text-sm text-muted-foreground">{vehicle.model} · {vehicle.plate_number} · {vehicle.year ?? "—"} · {vehicle.mileage_km?.toLocaleString()} km</p>
        </div>
        <Badge>{vehicle.status.replace("_", " ")}</Badge>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Tracked parts</div><div className="text-2xl font-bold">{parts.length}</div></CardContent></Card>
        <Card><CardContent className="p-4"><div className="text-xs text-muted-foreground">Repair events</div><div className="text-2xl font-bold">{events.length}</div></CardContent></Card>
        <Card><CardContent className="p-4 flex items-center justify-between"><div><div className="text-xs text-muted-foreground">Total spent</div><div className="text-2xl font-bold">{totalSpent.toLocaleString()} USD</div></div><DollarSign className="h-6 w-6 text-accent" /></CardContent></Card>
      </div>

      <h2 className="mt-8 mb-3 text-xl font-bold">Spare Parts</h2>
      <div className="mb-3 flex flex-wrap gap-2">
        <Input placeholder="Search part…" value={search} onChange={(e) => setSearch(e.target.value)} className="max-w-xs" />
        <Select value={filterCat} onValueChange={setFilterCat}>
          <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="max-h-[500px] overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-card text-left text-xs uppercase text-muted-foreground">
                <tr><th className="p-3">Part</th><th className="p-3">Category</th><th className="p-3">Status</th><th className="p-3 text-right">Price (USD)</th><th className="p-3">Action</th></tr>
              </thead>
              <tbody>
                {filteredCatalog.map((cp) => {
                  const vp = partMap.get(cp.id);
                  return (
                    <tr key={cp.id} className="border-t hover:bg-secondary/50">
                      <td className="p-3 font-medium">{cp.name}<div className="text-xs text-muted-foreground">{cp.part_number}</div></td>
                      <td className="p-3 text-muted-foreground">{cp.category}</td>
                      <td className="p-3"><Badge variant={vp ? PART_STATUS_COLOR[vp.status] : "secondary"}>{vp?.status?.replace("_"," ") ?? "untracked"}</Badge></td>
                      <td className="p-3 text-right">{vp?.current_price ? Number(vp.current_price).toLocaleString() : "—"}</td>
                      <td className="p-3">
                        {canEdit && <Button size="sm" variant="outline" onClick={() => setSelectedPart({ catalog: cp, vp })}><Wrench className="mr-1 h-3 w-3" />Log</Button>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <h2 className="mt-8 mb-3 text-xl font-bold flex items-center gap-2"><History className="h-5 w-5" />Repair History</h2>
      {events.length === 0 ? (
        <Card><CardContent className="py-6 text-center text-muted-foreground">No repair events yet.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {events.map((e) => (
            <Card key={e.id}>
              <CardContent className="p-4">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <div className="font-semibold">{e.parts_catalog?.name ?? "Part"} <Badge variant="secondary" className="ml-2">{e.event_type}</Badge></div>
                    <div className="text-xs text-muted-foreground">{format(new Date(e.created_at), "MMM d, yyyy HH:mm")}</div>
                    {e.description && <p className="mt-1 text-sm">{e.description}</p>}
                  </div>
                  <div className="text-right"><div className="text-lg font-bold">{Number(e.cost).toLocaleString()} USD</div></div>
                </div>
                {e.image_urls?.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {e.image_urls.map((u: string, i: number) => (
                      <a key={i} href={u} target="_blank" rel="noreferrer">
                        <img src={u} alt="" className="h-20 w-20 rounded border object-cover hover:opacity-80" />
                      </a>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <h2 className="mt-8 mb-3 text-xl font-bold">Safari Trips</h2>
      {trips.length === 0 ? (
        <Card><CardContent className="py-6 text-center text-muted-foreground">No trips logged.</CardContent></Card>
      ) : (
        <div className="space-y-2">
          {trips.map((t) => (
            <Card key={t.id}><CardContent className="flex items-center justify-between p-3 text-sm">
              <div><div className="font-medium">{t.destination}</div><div className="text-xs text-muted-foreground">{format(new Date(t.start_date), "MMM d, yyyy")} · {t.planned_days} days · {t.driver_name ?? "—"}</div></div>
              <Badge variant={t.status === "overdue" ? "destructive" : "secondary"}>{t.status.replace("_", " ")}</Badge>
            </CardContent></Card>
          ))}
        </div>
      )}

      {selectedPart && (
        <LogRepairDialog vehicleId={id} part={selectedPart} onClose={() => setSelectedPart(null)} onSaved={load} />
      )}
    </div>
  );
}

function LogRepairDialog({ vehicleId, part, onClose, onSaved }: any) {
  const [eventType, setEventType] = useState("repaired");
  const [status, setStatus] = useState(part.vp?.status ?? "ok");
  const [cost, setCost] = useState(part.vp?.current_price ?? "");
  const [description, setDescription] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [price, setPrice] = useState(part.vp?.current_price ?? "");
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    let vpId = part.vp?.id;
    if (!vpId) {
      const { data, error } = await supabase.from("vehicle_parts")
        .insert({ vehicle_id: vehicleId, catalog_part_id: part.catalog.id, status, current_price: price ? Number(price) : null })
        .select().single();
      if (error) { setBusy(false); return toast.error(error.message); }
      vpId = data.id;
    } else {
      await supabase.from("vehicle_parts").update({
        status, current_price: price ? Number(price) : null, last_serviced_at: new Date().toISOString(),
      }).eq("id", vpId);
    }
    const { error } = await supabase.from("part_events").insert({
      vehicle_id: vehicleId, vehicle_part_id: vpId, catalog_part_id: part.catalog.id,
      event_type: eventType as any, cost: cost ? Number(cost) : 0, description, image_urls: images,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Logged");
    onSaved(); onClose();
  }

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>{part.catalog.name}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Event</Label>
              <Select value={eventType} onValueChange={setEventType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="inspected">Inspected</SelectItem>
                  <SelectItem value="repaired">Repaired</SelectItem>
                  <SelectItem value="replaced">Replaced</SelectItem>
                  <SelectItem value="installed">Installed</SelectItem>
                  <SelectItem value="damaged">Damaged</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div><Label>New status</Label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ok">OK</SelectItem>
                  <SelectItem value="needs_inspection">Needs inspection</SelectItem>
                  <SelectItem value="needs_repair">Needs repair</SelectItem>
                  <SelectItem value="needs_replacement">Needs replacement</SelectItem>
                  <SelectItem value="replaced">Replaced</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Cost (USD)</Label><Input type="number" value={cost} onChange={(e) => setCost(e.target.value)} /></div>
            <div><Label>Current price (USD)</Label><Input type="number" value={price} onChange={(e) => setPrice(e.target.value)} /></div>
          </div>
          <div><Label>Notes / description</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} /></div>
          <div><Label>Photos (before/after)</Label><ImageUploader value={images} onChange={setImages} folder={`vehicle-${vehicleId}`} /></div>
          <Button onClick={submit} disabled={busy} className="w-full">{busy ? "Saving…" : "Save event"}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
