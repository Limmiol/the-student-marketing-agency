import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Plus, Truck } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/vehicles")({ component: VehiclesPage });

const STATUS_COLOR: Record<string, "default" | "secondary" | "destructive"> = {
  available: "default", on_safari: "secondary", in_repair: "destructive", out_of_service: "destructive",
};

function VehiclesPage() {
  const { role } = useAuth();
  const canEdit = role === "admin" || role === "manager";
  const [list, setList] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", plate_number: "", model: "Land Cruiser", year: "", color: "", mileage_km: "", status: "available" });

  async function load() {
    const { data } = await supabase.from("vehicles").select("*").order("name");
    setList(data ?? []);
  }
  useEffect(() => {
    load();
    const ch = supabase.channel("vehicles").on("postgres_changes", { event: "*", schema: "public", table: "vehicles" }, load).subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  async function save() {
    if (!form.name || !form.plate_number) return toast.error("Name & plate required");
    const { error } = await supabase.from("vehicles").insert({
      name: form.name, plate_number: form.plate_number, model: form.model,
      year: form.year ? Number(form.year) : null, color: form.color || null,
      mileage_km: form.mileage_km ? Number(form.mileage_km) : 0,
      status: form.status as any,
    });
    if (error) return toast.error(error.message);
    toast.success("Vehicle added");
    setOpen(false);
    setForm({ name: "", plate_number: "", model: "Land Cruiser", year: "", color: "", mileage_km: "", status: "available" });
  }

  return (
    <div>
      <PageHeader title="Vehicles" description="Your safari fleet" action={
        canEdit && (
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />Add vehicle</Button></DialogTrigger>
            <DialogContent>
              <DialogHeader><DialogTitle>New vehicle</DialogTitle></DialogHeader>
              <div className="space-y-3">
                <div><Label>Name / Nickname</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Cruiser 1" /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Plate</Label><Input value={form.plate_number} onChange={(e) => setForm({ ...form, plate_number: e.target.value })} /></div>
                  <div><Label>Year</Label><Input type="number" value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })} /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Model</Label><Input value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} /></div>
                  <div><Label>Color</Label><Input value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Mileage (km)</Label><Input type="number" value={form.mileage_km} onChange={(e) => setForm({ ...form, mileage_km: e.target.value })} /></div>
                  <div><Label>Status</Label>
                    <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="available">Available</SelectItem>
                        <SelectItem value="on_safari">On safari</SelectItem>
                        <SelectItem value="in_repair">In repair</SelectItem>
                        <SelectItem value="out_of_service">Out of service</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button onClick={save} className="w-full">Save</Button>
              </div>
            </DialogContent>
          </Dialog>
        )
      } />

      {list.length === 0 ? (
        <Card><CardContent className="py-10 text-center text-muted-foreground">No vehicles yet. {canEdit && "Add your first Land Cruiser."}</CardContent></Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {list.map((v) => (
            <Link key={v.id} to="/vehicles/$id" params={{ id: v.id }} className="block">
              <Card className="transition hover:border-primary hover:shadow-md">
                <CardContent className="p-4">
                  <div className="mb-3 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary"><Truck className="h-5 w-5" /></div>
                      <div>
                        <div className="font-semibold">{v.name}</div>
                        <div className="text-xs text-muted-foreground">{v.plate_number}</div>
                      </div>
                    </div>
                    <Badge variant={STATUS_COLOR[v.status]}>{v.status.replace("_", " ")}</Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div><div className="text-muted-foreground">Year</div><div className="font-medium">{v.year ?? "—"}</div></div>
                    <div><div className="text-muted-foreground">Color</div><div className="font-medium">{v.color ?? "—"}</div></div>
                    <div><div className="text-muted-foreground">km</div><div className="font-medium">{v.mileage_km?.toLocaleString() ?? 0}</div></div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
