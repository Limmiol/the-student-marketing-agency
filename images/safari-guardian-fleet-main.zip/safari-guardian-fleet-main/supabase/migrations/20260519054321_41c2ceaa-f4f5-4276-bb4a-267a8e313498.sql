
-- =========================================
-- ENUMS
-- =========================================
CREATE TYPE public.app_role AS ENUM ('admin', 'manager', 'driver');
CREATE TYPE public.vehicle_status AS ENUM ('available', 'on_safari', 'in_repair', 'out_of_service');
CREATE TYPE public.part_status AS ENUM ('ok', 'needs_inspection', 'needs_repair', 'needs_replacement', 'replaced');
CREATE TYPE public.event_type AS ENUM ('installed', 'inspected', 'repaired', 'replaced', 'damaged');
CREATE TYPE public.request_status AS ENUM ('pending', 'approved', 'rejected', 'purchased');
CREATE TYPE public.request_urgency AS ENUM ('low', 'medium', 'high', 'critical');
CREATE TYPE public.trip_status AS ENUM ('planned', 'in_progress', 'completed', 'overdue', 'cancelled');

-- =========================================
-- PROFILES
-- =========================================
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  phone TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- =========================================
-- USER ROLES (separate table for security)
-- =========================================
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE OR REPLACE FUNCTION public.get_user_role(_user_id UUID)
RETURNS public.app_role
LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT role FROM public.user_roles WHERE user_id = _user_id ORDER BY
    CASE role WHEN 'admin' THEN 1 WHEN 'manager' THEN 2 WHEN 'driver' THEN 3 END
  LIMIT 1
$$;

-- Auto-create profile + assign role on signup (first user = admin, rest = manager)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count INT;
  assigned_role public.app_role;
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email));

  SELECT COUNT(*) INTO user_count FROM public.user_roles;
  IF user_count = 0 THEN
    assigned_role := 'admin';
  ELSE
    assigned_role := 'manager';
  END IF;

  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, assigned_role);
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- =========================================
-- VEHICLES
-- =========================================
CREATE TABLE public.vehicles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  plate_number TEXT NOT NULL UNIQUE,
  model TEXT NOT NULL DEFAULT 'Land Cruiser',
  year INT,
  color TEXT,
  vin TEXT,
  mileage_km INT NOT NULL DEFAULT 0,
  status public.vehicle_status NOT NULL DEFAULT 'available',
  image_url TEXT,
  notes TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.vehicles ENABLE ROW LEVEL SECURITY;

-- =========================================
-- PARTS CATALOG (master list, shared across vehicles)
-- =========================================
CREATE TABLE public.parts_catalog (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category TEXT NOT NULL,
  name TEXT NOT NULL,
  part_number TEXT,
  description TEXT,
  default_price NUMERIC(12,2),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.parts_catalog ENABLE ROW LEVEL SECURITY;
CREATE INDEX ON public.parts_catalog (category);

-- =========================================
-- VEHICLE PARTS (per-vehicle status of each catalog part)
-- =========================================
CREATE TABLE public.vehicle_parts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  catalog_part_id UUID NOT NULL REFERENCES public.parts_catalog(id) ON DELETE RESTRICT,
  status public.part_status NOT NULL DEFAULT 'ok',
  current_price NUMERIC(12,2),
  last_serviced_at TIMESTAMPTZ,
  notes TEXT,
  updated_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(vehicle_id, catalog_part_id)
);
ALTER TABLE public.vehicle_parts ENABLE ROW LEVEL SECURITY;
CREATE INDEX ON public.vehicle_parts (vehicle_id);

-- =========================================
-- PART EVENTS (timeline of changes / repairs with images)
-- =========================================
CREATE TABLE public.part_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  vehicle_part_id UUID REFERENCES public.vehicle_parts(id) ON DELETE SET NULL,
  catalog_part_id UUID REFERENCES public.parts_catalog(id) ON DELETE SET NULL,
  event_type public.event_type NOT NULL,
  cost NUMERIC(12,2) NOT NULL DEFAULT 0,
  description TEXT,
  image_urls TEXT[] NOT NULL DEFAULT '{}',
  performed_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.part_events ENABLE ROW LEVEL SECURITY;
CREATE INDEX ON public.part_events (vehicle_id, created_at DESC);

-- =========================================
-- PURCHASE REQUESTS
-- =========================================
CREATE TABLE public.purchase_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID REFERENCES public.vehicles(id) ON DELETE SET NULL,
  catalog_part_id UUID REFERENCES public.parts_catalog(id) ON DELETE SET NULL,
  part_name_snapshot TEXT NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  estimated_price NUMERIC(12,2) NOT NULL DEFAULT 0,
  urgency public.request_urgency NOT NULL DEFAULT 'medium',
  status public.request_status NOT NULL DEFAULT 'pending',
  reason TEXT,
  admin_notes TEXT,
  requested_by UUID REFERENCES auth.users(id),
  reviewed_by UUID REFERENCES auth.users(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.purchase_requests ENABLE ROW LEVEL SECURITY;
CREATE INDEX ON public.purchase_requests (status, created_at DESC);

-- =========================================
-- SAFARI TRIPS
-- =========================================
CREATE TABLE public.safari_trips (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vehicle_id UUID NOT NULL REFERENCES public.vehicles(id) ON DELETE CASCADE,
  driver_id UUID REFERENCES auth.users(id),
  driver_name TEXT,
  client_name TEXT,
  destination TEXT NOT NULL,
  start_date DATE NOT NULL,
  planned_days INT NOT NULL DEFAULT 1,
  actual_return_date DATE,
  status public.trip_status NOT NULL DEFAULT 'planned',
  notes TEXT,
  start_mileage_km INT,
  end_mileage_km INT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.safari_trips ENABLE ROW LEVEL SECURITY;
CREATE INDEX ON public.safari_trips (status, start_date DESC);

-- =========================================
-- updated_at triggers
-- =========================================
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER t_profiles_updated BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER t_vehicles_updated BEFORE UPDATE ON public.vehicles
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER t_vehicle_parts_updated BEFORE UPDATE ON public.vehicle_parts
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER t_purchase_requests_updated BEFORE UPDATE ON public.purchase_requests
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER t_safari_trips_updated BEFORE UPDATE ON public.safari_trips
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- =========================================
-- RLS POLICIES
-- =========================================
-- profiles
CREATE POLICY "profiles_select_all_auth" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid());
CREATE POLICY "profiles_admin_all" ON public.profiles FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- user_roles
CREATE POLICY "roles_select_own" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "roles_admin_all" ON public.user_roles FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- vehicles: everyone authenticated reads; manager+admin write
CREATE POLICY "vehicles_select" ON public.vehicles FOR SELECT TO authenticated USING (true);
CREATE POLICY "vehicles_insert" ON public.vehicles FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'manager'));
CREATE POLICY "vehicles_update" ON public.vehicles FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'manager'));
CREATE POLICY "vehicles_delete" ON public.vehicles FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(),'admin'));

-- parts_catalog: all read, manager+admin write
CREATE POLICY "catalog_select" ON public.parts_catalog FOR SELECT TO authenticated USING (true);
CREATE POLICY "catalog_write" ON public.parts_catalog FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'manager'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'manager'));

-- vehicle_parts
CREATE POLICY "vparts_select" ON public.vehicle_parts FOR SELECT TO authenticated USING (true);
CREATE POLICY "vparts_write" ON public.vehicle_parts FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'manager'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'manager'));

-- part_events
CREATE POLICY "events_select" ON public.part_events FOR SELECT TO authenticated USING (true);
CREATE POLICY "events_write" ON public.part_events FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'manager'))
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'manager'));

-- purchase_requests
CREATE POLICY "preq_select" ON public.purchase_requests FOR SELECT TO authenticated USING (true);
CREATE POLICY "preq_insert" ON public.purchase_requests FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'manager'));
CREATE POLICY "preq_update_manager_own" ON public.purchase_requests FOR UPDATE TO authenticated
  USING (
    public.has_role(auth.uid(),'admin')
    OR (public.has_role(auth.uid(),'manager') AND requested_by = auth.uid() AND status = 'pending')
  );
CREATE POLICY "preq_delete_admin" ON public.purchase_requests FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(),'admin'));

-- safari_trips
CREATE POLICY "trips_select" ON public.safari_trips FOR SELECT TO authenticated USING (true);
CREATE POLICY "trips_insert" ON public.safari_trips FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'manager'));
CREATE POLICY "trips_update" ON public.safari_trips FOR UPDATE TO authenticated
  USING (
    public.has_role(auth.uid(),'admin')
    OR public.has_role(auth.uid(),'manager')
    OR (public.has_role(auth.uid(),'driver') AND driver_id = auth.uid())
  );
CREATE POLICY "trips_delete" ON public.safari_trips FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(),'admin'));

-- =========================================
-- REALTIME
-- =========================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.vehicles;
ALTER PUBLICATION supabase_realtime ADD TABLE public.part_events;
ALTER PUBLICATION supabase_realtime ADD TABLE public.purchase_requests;
ALTER PUBLICATION supabase_realtime ADD TABLE public.safari_trips;
ALTER PUBLICATION supabase_realtime ADD TABLE public.vehicle_parts;

ALTER TABLE public.vehicles REPLICA IDENTITY FULL;
ALTER TABLE public.part_events REPLICA IDENTITY FULL;
ALTER TABLE public.purchase_requests REPLICA IDENTITY FULL;
ALTER TABLE public.safari_trips REPLICA IDENTITY FULL;
ALTER TABLE public.vehicle_parts REPLICA IDENTITY FULL;

-- =========================================
-- STORAGE BUCKET for part images
-- =========================================
INSERT INTO storage.buckets (id, name, public) VALUES ('part-images', 'part-images', true)
  ON CONFLICT (id) DO NOTHING;

CREATE POLICY "part_images_public_read" ON storage.objects FOR SELECT
  USING (bucket_id = 'part-images');
CREATE POLICY "part_images_auth_insert" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'part-images');
CREATE POLICY "part_images_auth_update" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'part-images');
CREATE POLICY "part_images_admin_delete" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'part-images' AND public.has_role(auth.uid(),'admin'));

-- =========================================
-- DAILY MARK-OVERDUE FUNCTION (used by reports / cron-less polling)
-- =========================================
CREATE OR REPLACE FUNCTION public.refresh_trip_statuses()
RETURNS VOID LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.safari_trips
    SET status = 'in_progress'
    WHERE status = 'planned' AND start_date <= CURRENT_DATE AND actual_return_date IS NULL;

  UPDATE public.safari_trips
    SET status = 'overdue'
    WHERE status = 'in_progress'
      AND actual_return_date IS NULL
      AND (start_date + (planned_days || ' days')::interval)::date < CURRENT_DATE;
END;
$$;
